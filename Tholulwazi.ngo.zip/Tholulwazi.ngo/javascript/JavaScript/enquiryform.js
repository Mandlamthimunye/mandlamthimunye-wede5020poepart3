
if (menuToggle && mainNav) {

    // Open or close the mobile navigation
    menuToggle.addEventListener("click", () => {

        const isOpen = mainNav.classList.toggle("open");

        // Update the accessibility attribute
        menuToggle.setAttribute(
            "aria-expanded",
            String(isOpen)
        );

    });


    // Close the navigation after selecting a link
    mainNav.querySelectorAll("a").forEach(link => {

        link.addEventListener("click", () => {

            mainNav.classList.remove("open");

            menuToggle.setAttribute(
                "aria-expanded",
                "false"
            );

        });

    });

}


/* =========================================================
   2. AUTOMATIC COPYRIGHT YEAR
========================================================= */

// Get the current year
const currentYear = document.getElementById("current-year");

if (currentYear) {

    currentYear.textContent = new Date().getFullYear();

}


/* =========================================================
   3. ENQUIRY FORM VALIDATION
========================================================= */

// Select the enquiry form and feedback message
const enquiryForm = document.getElementById("enquiry-form");
const formStatus = document.getElementById("form-status");


if (enquiryForm && formStatus) {

    enquiryForm.addEventListener("submit", function (event) {

        // Prevent the browser from submitting an unconfigured form
        event.preventDefault();


        // Check all required fields and input formats
        if (!enquiryForm.checkValidity()) {

            // Ask the browser to identify invalid fields
            enquiryForm.reportValidity();

            showFormMessage(
                "Please complete all required fields correctly.",
                "error"
            );

            return;

        }


        // Check the privacy consent checkbox
        const consent = document.getElementById("privacy-consent");

        if (!consent || !consent.checked) {

            showFormMessage(
                "Please confirm that you agree to the privacy notice before continuing.",
                "error"
            );

            return;

        }


       

        showFormMessage(
            "Your information has passed the form validation checks. " +
            "This website is not yet connected to an email service or database, " +
            "so your enquiry has not been sent.",
            "info"
        );

    });

}


/* =========================================================
   4. DISPLAY FORM FEEDBACK
========================================================= */

function showFormMessage(message, type) {

    if (!formStatus) {
        return;
    }

    // Display the message
    formStatus.textContent = message;

    // Apply the appropriate feedback style
    formStatus.className = "form-status is-visible " + type;

    // Move keyboard and screen-reader focus to the feedback
    formStatus.setAttribute("tabindex", "-1");
    formStatus.focus();

}
